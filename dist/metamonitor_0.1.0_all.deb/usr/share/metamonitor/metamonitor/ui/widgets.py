"""Custom widgets drawn with GSK render nodes.

Everything here goes through ``Gtk.Snapshot`` (gradients, rounded clips,
blurred shadows, filled and stroked paths), which GTK 4.14+ renders on the
GPU with its Vulkan or GL renderer.  No Cairo rasterisation, no custom
shaders to maintain.

SPDX-License-Identifier: Unlicense
"""

import math

import gi

gi.require_version("Gdk", "4.0")
gi.require_version("Gtk", "4.0")
gi.require_version("Gsk", "4.0")
gi.require_version("Graphene", "1.0")
from gi.repository import Gdk, Graphene, Gsk, Gtk  # noqa: E402

STATE_COLORS = {
    "done": ("#22c55e", "#86efac"),
    "failed": ("#ef4444", "#f97316"),
    "paused": ("#f59e0b", "#fde047"),
    "blocked": ("#f59e0b", "#fb7185"),
    "idle": ("#64748b", "#94a3b8"),
}


def rgba(spec, alpha=1.0):
    c = Gdk.RGBA()
    c.parse(spec)
    c.alpha *= alpha
    return c


def stops(*pairs):
    out = []
    for offset, color in pairs:
        s = Gsk.ColorStop()
        s.offset = offset
        s.color = color
        out.append(s)
    return out


def rect(x, y, w, h):
    return Graphene.Rect().init(x, y, w, h)


def round_path(x, y, w, h, r):
    """Rounded rectangle as a GskPath.

    Built by hand because GskRoundedRect (an inline struct array) crashes
    PyGObject; paths go through the same GPU pipeline anyway.
    """
    r = max(0.0, min(r, w / 2, h / 2))
    b = Gsk.PathBuilder.new()
    b.move_to(x + r, y)
    b.line_to(x + w - r, y)
    b.svg_arc_to(r, r, 0, False, True, x + w, y + r)
    b.line_to(x + w, y + h - r)
    b.svg_arc_to(r, r, 0, False, True, x + w - r, y + h)
    b.line_to(x + r, y + h)
    b.svg_arc_to(r, r, 0, False, True, x, y + h - r)
    b.line_to(x, y + r)
    b.svg_arc_to(r, r, 0, False, True, x + r, y)
    b.close()
    return b.to_path()


def push_round_clip(snap, x, y, w, h, r):
    snap.push_fill(round_path(x, y, w, h, r), Gsk.FillRule.WINDING)


def point(x, y):
    return Graphene.Point().init(x, y)


class GlowBar(Gtk.Widget):
    """A neon progress bar: gradient fill, soft glow, moving sheen.

    ``fraction`` None means indeterminate (a comet sweeps the track).
    """

    __gtype_name__ = "MMGlowBar"

    def __init__(self, c0="#22d3ee", c1="#6366f1", height=10):
        super().__init__()
        self.set_size_request(60, height + 8)
        self.set_hexpand(True)
        self.colors = (c0, c1)
        self.bar_h = height
        self.target = None
        self.shown = 0.0
        self.state = "running"
        self.phase = 0.0
        self._last = None
        self._tick = None

    def set_progress(self, fraction, state):
        if fraction is not None:
            fraction = max(0.0, min(1.0, fraction))
            if self.target is None:
                self.shown = fraction if state != "running" else 0.0
        self.target, self.state = fraction, state
        self._ensure_tick()
        self.queue_draw()

    def _animating(self):
        if self.state in ("running", "blocked"):
            return True
        return self.target is not None and abs(self.target - self.shown) > 1e-3

    def _ensure_tick(self):
        if self._tick is None and self._animating():
            self._last = None
            self._tick = self.add_tick_callback(self._on_tick)

    def _on_tick(self, widget, clock):
        t = clock.get_frame_time() / 1e6
        dt = 0.016 if self._last is None else min(0.1, t - self._last)
        self._last = t
        self.phase = (self.phase + dt) % 1000.0
        if self.target is not None:
            # Critically damped approach: smooth but never overshoots.
            self.shown += (self.target - self.shown) * (1 - math.exp(-dt * 6))
        self.queue_draw()
        if not self._animating():
            self._tick = None
            return False
        return True

    def do_snapshot(self, snap):
        w, h = self.get_width(), self.get_height()
        bh = self.bar_h
        y = (h - bh) / 2
        r = bh / 2
        c0, c1 = STATE_COLORS.get(self.state, self.colors)

        push_round_clip(snap, 0, y, w, bh, r)
        snap.append_linear_gradient(
            rect(0, y, w, bh), point(0, y), point(0, y + bh),
            stops((0.0, rgba("#000000", 0.45)), (1.0, rgba("#ffffff", 0.07))),
        )
        snap.pop()

        if self.target is None:
            self._comet(snap, w, y, bh, r, c0, c1)
            return
        fw = max(bh, w * self.shown) if self.shown > 0.001 else 0
        if fw <= 0:
            return
        if self.state != "idle":
            snap.push_blur(6)
            snap.append_fill(round_path(0, y, fw, bh, r), Gsk.FillRule.WINDING, rgba(c1, 0.55))
            snap.pop()
        push_round_clip(snap, 0, y, fw, bh, r)
        snap.append_linear_gradient(
            rect(0, y, fw, bh), point(0, 0), point(max(w, 1), 0),
            stops((0.0, rgba(c0)), (1.0, rgba(c1))),
        )
        # Top highlight gives the bar a glassy, lit-from-above look.
        snap.append_linear_gradient(
            rect(0, y, fw, bh), point(0, y), point(0, y + bh),
            stops((0.0, rgba("#ffffff", 0.35)), (0.5, rgba("#ffffff", 0.0)),
                  (1.0, rgba("#000000", 0.15))),
        )
        if self.state == "running":
            band = 140.0
            x = ((self.phase * 0.45) % 1.0) * (fw + 2 * band) - band
            snap.append_linear_gradient(
                rect(x, y, band, bh), point(x, 0), point(x + band, 0),
                stops((0.0, rgba("#ffffff", 0.0)), (0.5, rgba("#ffffff", 0.35)),
                      (1.0, rgba("#ffffff", 0.0))),
            )
        snap.pop()

    def _comet(self, snap, w, y, bh, r, c0, c1):
        if self.state not in ("running", "blocked"):
            push_round_clip(snap, 0, y, w, bh, r)
            snap.append_linear_gradient(
                rect(0, y, w, bh), point(0, 0), point(w, 0),
                stops((0.0, rgba(c0, 0.35)), (1.0, rgba(c1, 0.35))),
            )
            snap.pop()
            return
        cw = max(60.0, w * 0.28)
        s = (math.sin(self.phase * 1.7) + 1) / 2
        x = s * (w + cw) - cw
        push_round_clip(snap, 0, y, w, bh, r)
        snap.append_linear_gradient(
            rect(x, y, cw, bh), point(x, 0), point(x + cw, 0),
            stops((0.0, rgba(c0, 0.0)), (0.5, rgba(c0, 0.95)), (1.0, rgba(c1, 0.0))),
        )
        snap.pop()


class RingGauge(Gtk.Widget):
    """A circular gauge with a conic-gradient arc and a centred value."""

    __gtype_name__ = "MMRingGauge"

    def __init__(self, label, c0, c1, size=112):
        super().__init__()
        self.set_size_request(size, size)
        self.c0, self.c1 = c0, c1
        self.value = 0.0
        self.shown = 0.0
        self.text = "0"
        self.caption = label
        self._tick = None
        self.set_layout_manager(Gtk.BinLayout())
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
        self.big = Gtk.Label(label="0", css_classes=["mm-gauge-value"])
        self.small = Gtk.Label(label=label, css_classes=["mm-gauge-caption"])
        box.append(self.big)
        box.append(self.small)
        box.set_parent(self)

    def set_value(self, fraction, text):
        self.value = max(0.0, min(1.0, fraction))
        self.big.set_label(text)
        if self._tick is None:
            self._tick = self.add_tick_callback(self._on_tick)

    def _on_tick(self, *_):
        self.shown += (self.value - self.shown) * 0.12
        self.queue_draw()
        if abs(self.value - self.shown) < 1e-3:
            self.shown = self.value
            self._tick = None
            return False
        return True

    def do_snapshot(self, snap):
        w, h = self.get_width(), self.get_height()
        d = min(w, h)
        lw = 9.0
        r = d / 2 - lw
        cx, cy = w / 2, h / 2
        stroke = Gsk.Stroke.new(lw)
        stroke.set_line_cap(Gsk.LineCap.ROUND)

        b = Gsk.PathBuilder.new()
        b.add_circle(point(cx, cy), r)
        snap.append_stroke(b.to_path(), stroke, rgba("#ffffff", 0.07))

        f = self.shown
        if f > 0.002:
            a0 = -math.pi / 2
            a1 = a0 + 2 * math.pi * min(f, 0.9999)
            b = Gsk.PathBuilder.new()
            b.move_to(cx + r * math.cos(a0), cy + r * math.sin(a0))
            b.svg_arc_to(r, r, 0, f > 0.5, True, cx + r * math.cos(a1), cy + r * math.sin(a1))
            path = b.to_path()
            bounds = rect(cx - r - lw, cy - r - lw, 2 * (r + lw), 2 * (r + lw))
            snap.push_blur(6)
            snap.push_stroke(path, stroke)
            snap.append_color(rgba(self.c1, 0.6), bounds)
            snap.pop()
            snap.pop()
            snap.push_stroke(path, stroke)
            snap.append_conic_gradient(
                bounds, point(cx, cy), 0,
                stops((0.0, rgba(self.c0)), (0.5, rgba(self.c1)), (1.0, rgba(self.c0))),
            )
            snap.pop()
        child = self.get_first_child()
        if child:
            self.snapshot_child(child, snap)


class HistoryChart(Gtk.Widget):
    """btop-style area chart: active task count and mean completion over time."""

    __gtype_name__ = "MMHistoryChart"

    def __init__(self, seconds=600):
        super().__init__()
        self.set_size_request(240, 112)
        self.set_hexpand(True)
        self.seconds = seconds
        self.samples = []  # (t, active, mean_percent or None)

    def add(self, t, active, mean):
        self.samples.append((t, active, mean))
        cutoff = t - self.seconds
        while self.samples and self.samples[0][0] < cutoff:
            self.samples.pop(0)
        self.queue_draw()

    def do_snapshot(self, snap):
        w, h = self.get_width(), self.get_height()
        pad = 6.0
        top, bot = pad, h - pad
        push_round_clip(snap, 0, 0, w, h, 14)
        snap.append_color(rgba("#ffffff", 0.03), rect(0, 0, w, h))
        grid = rgba("#ffffff", 0.06)
        for i in range(1, 4):
            gy = top + (bot - top) * i / 4
            snap.append_color(grid, rect(0, gy, w, 1))
        for i in range(1, 10):
            snap.append_color(grid, rect(w * i / 10, 0, 1, h))
        if len(self.samples) >= 2:
            t_end = self.samples[-1][0]
            # The window grows with the data, up to ``seconds``, so the chart
            # is filled from the first minute on.
            span = min(self.seconds, max(60.0, t_end - self.samples[0][0]))
            t0 = t_end - span
            peak = max(2, max(s[1] for s in self.samples))

            def xy(t, v):
                return w * (t - t0) / span, bot - (bot - top) * v

            self._area(snap, [xy(t, a / peak) for t, a, _ in self.samples],
                       "#d97757", "#f4b183", bot)
            pts = [xy(t, m / 100) for t, _, m in self.samples if m is not None]
            if len(pts) >= 2:
                self._area(snap, pts, "#22d3ee", "#6366f1", bot, fill_alpha=0.18)
        snap.pop()

    @staticmethod
    def _area(snap, pts, c0, c1, bottom, fill_alpha=0.35):
        line = Gsk.PathBuilder.new()
        area = Gsk.PathBuilder.new()
        area.move_to(pts[0][0], bottom)
        for i, (x, y) in enumerate(pts):
            (line.move_to if i == 0 else line.line_to)(x, y)
            area.line_to(x, y)
        area.line_to(pts[-1][0], bottom)
        area.close()
        xs = [p[0] for p in pts]
        ytop = min(p[1] for p in pts)
        bounds = rect(min(xs), ytop - 4, max(1, max(xs) - min(xs)), bottom - ytop + 4)
        snap.push_fill(area.to_path(), Gsk.FillRule.WINDING)
        snap.append_linear_gradient(
            bounds, point(0, ytop), point(0, bottom),
            stops((0.0, rgba(c1, fill_alpha)), (1.0, rgba(c0, 0.0))),
        )
        snap.pop()
        stroke = Gsk.Stroke.new(2.0)
        stroke.set_line_join(Gsk.LineJoin.ROUND)
        snap.push_stroke(line.to_path(), stroke)
        snap.append_linear_gradient(
            rect(bounds.get_x(), bounds.get_y() - 2, bounds.get_width(), bounds.get_height() + 4),
            point(bounds.get_x(), 0), point(bounds.get_x() + bounds.get_width(), 0),
            stops((0.0, rgba(c0)), (1.0, rgba(c1))),
        )
        snap.pop()
