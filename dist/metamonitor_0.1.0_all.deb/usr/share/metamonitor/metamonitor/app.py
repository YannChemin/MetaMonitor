"""Application entry point.

SPDX-License-Identifier: Unlicense
"""

import sys
import time
import traceback
from pathlib import Path

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, Gio, GLib, Gtk  # noqa: E402

from . import APP_ID, __version__, spool  # noqa: E402
from .collectors.claude import ClaudeCollector  # noqa: E402
from .collectors.procfs import ProcCollector  # noqa: E402
from .collectors.slots import SlotCollector  # noqa: E402
from .collectors.unity import UnityCollector  # noqa: E402
from .model import Store  # noqa: E402

NOTIFY_MIN_RUNTIME = 60  # Only notify for tasks that ran at least this long.


class MetaMonitor(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.DEFAULT_FLAGS)
        self.store = Store()
        self.collectors = []
        self.notify = True
        self.window = None
        self._tick = 0
        self._spool_monitor = None

    def do_startup(self):
        Adw.Application.do_startup(self)
        Adw.StyleManager.get_default().set_color_scheme(Adw.ColorScheme.FORCE_DARK)
        css = Gtk.CssProvider()
        css.load_from_path(str(Path(__file__).parent / "ui" / "style.css"))
        Gtk.StyleContext.add_provider_for_display(
            Gdk.Display.get_default(), css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
        for name, cb, accel in (
            ("quit", lambda *_: self.quit(), "<primary>q"),
            ("clear", self._clear, "<primary>l"),
            ("about", self._about, None),
        ):
            act = Gio.SimpleAction.new(name, None)
            act.connect("activate", cb)
            self.add_action(act)
            if accel:
                self.set_accels_for_action(f"app.{name}", [accel])
        act = Gio.SimpleAction.new_stateful("notify", None, GLib.Variant.new_boolean(True))
        act.connect("change-state", self._on_notify)
        self.add_action(act)

        self.collectors = [
            (SlotCollector(), 1),
            (ClaudeCollector(), 2),
            (ProcCollector(), 2),
            (UnityCollector(), 2),
        ]
        # Slots also refresh instantly when a file changes in the spool.
        self._spool_monitor = Gio.File.new_for_path(str(spool.spool_dir())).monitor_directory(
            Gio.FileMonitorFlags.NONE, None
        )
        self._spool_monitor.set_rate_limit(100)
        self._spool_monitor.connect("changed", lambda *_: self._poll_one(self.collectors[0][0]))
        GLib.timeout_add(500, self._poll)

    def do_activate(self):
        if self.window is None:
            from .ui.window import MainWindow

            self.window = MainWindow(self, self.store)
            self._poll(force=True)
        self.window.present()

    def _poll_one(self, collector):
        try:
            self.store.replace(collector.source, collector.poll())
        except Exception:
            traceback.print_exc()

    def _poll(self, force=False):
        self._tick += 1
        for collector, every in self.collectors:
            if force or self._tick % every == 0:
                self._poll_one(collector)
        return True

    def task_finished(self, task, prev):
        if not self.notify or time.time() - task.started < NOTIFY_MIN_RUNTIME:
            return
        if task.group == "claude" and not task.parent and task.state == "idle":
            title = f"Claude is waiting: {task.title}"
        elif task.state == "idle":
            return
        else:
            title = f"{'Finished' if task.state == 'done' else 'Failed'}: {task.title}"
        n = Gio.Notification.new(title)
        n.set_body(task.detail or task.subtitle)
        n.set_priority(
            Gio.NotificationPriority.HIGH if task.state == "failed"
            else Gio.NotificationPriority.NORMAL
        )
        self.send_notification(task.id, n)

    def _on_notify(self, action, value):
        action.set_state(value)
        self.notify = value.get_boolean()

    def _clear(self, *_):
        for s in spool.list_slots():
            if s["state"] in ("done", "failed"):
                spool.remove_slot(s["id"])
        self._poll(force=True)

    def _about(self, *_):
        about = Adw.AboutDialog(
            application_name="MetaMonitor",
            application_icon="utilities-system-monitor",
            version=__version__,
            developer_name="Yann Chemin",
            license_type=Gtk.License.CUSTOM,
            license="Released into the public domain (The Unlicense).",
            comments=(
                "Live progress for Claude Code sessions, wrapped CLIs, "
                "file copies and desktop applications."
            ),
        )
        about.present(self.window)


def main():
    return MetaMonitor().run(sys.argv)
